package com.example.admin.gallery.Gall;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.example.admin.gallery.R;
import com.example.admin.gallery.gallery.DetailActivity;

import java.io.ByteArrayInputStream;
import java.util.List;

public class DetailAdapter extends BaseAdapter {
    private DetailActivity context;
    private int layout;
    private List<Gall> listDV;
    public DetailAdapter(DetailActivity context, int layout, List<Gall> listDV) {
        this.context = context;
        this.layout = layout;
        this.listDV = listDV;
    }

    @Override
    public int getCount() {
        return listDV.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    private class ViewHoler{
        ImageView imgDetail;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHoler holer ;
        if(convertView == null){
            holer = new ViewHoler();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(layout,null);
            holer.imgDetail =(ImageView) convertView.findViewById(R.id.imgDetail);

            convertView.setTag(holer);
        }else{
            holer = (ViewHoler) convertView.getTag();
        }
        final Gall gall = listDV.get(position);
        byte[] hinhAnh = gall.getHinh();
        ByteArrayInputStream imageStream = new ByteArrayInputStream(hinhAnh);
        Bitmap theImage = BitmapFactory.decodeStream(imageStream);


        holer.imgDetail.setImageBitmap(theImage);
        holer.imgDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.dialogSua(gall);
            }
        });
        return convertView;
    }



}
