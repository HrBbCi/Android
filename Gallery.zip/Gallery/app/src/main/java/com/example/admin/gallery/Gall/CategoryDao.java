package com.example.admin.gallery.Gall;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import com.example.admin.gallery.database.Database;

import java.util.ArrayList;
import java.util.List;

public class CategoryDao {
    private Database database;
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "gallery.db";
    private static final String TABLE_CAT= "category";
    private static final String COLUMN_ID = "Id";
    private static final String COLUMN_TYPE = "Type";
    private static final String COLUMN_HINHANH = "HinhAnh";

    private String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_CAT + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_TYPE + " VARCHAR(150),"
            + COLUMN_HINHANH + " BLOB)";

    private String DROP_TABLE = "DROP TABLE IF EXISTS " + TABLE_CAT;

    public CategoryDao(Context context) {
        database = new Database(context, DATABASE_NAME, null, DATABASE_VERSION);
        database.queryData(CREATE_TABLE);
    }

    public void addCat(Category ct) {
        try{
            SQLiteDatabase database1 = database.getWritableDatabase();
            String sql = "INSERT INTO category(Type,HinhAnh) VALUES(?,?)";
            SQLiteStatement statement = database1.compileStatement(sql);
            statement.clearBindings();
            statement.bindString(1, ct.getType());
            statement.bindBlob(2, ct.getHinh());
            statement.executeInsert();
        }catch (SQLException e){

        }finally {
            database.close();
        }

    }

    /**
     * This method is to fetch all user and return the list of user records
     *
     * @return list
     */
    public List<Category> getAllCat() {
        List<Category> gallList = new ArrayList<Category>();
        Cursor dataCV = database.getData("SELECT * FROM category ");
        Category gall = null;

        try{
            while (dataCV.moveToNext()) {
                long id = dataCV.getInt(0);
                String Type = dataCV.getString(1);
                byte[] HinhAnh = dataCV.getBlob(2);
                gall = new Category(id, Type, HinhAnh);
                gallList.add(gall);
            }
        }catch (SQLException e){

        }finally {
            database.close();
            dataCV.close();
        }

        return gallList;
    }

    public long findIDByType(String type) {
        long id = 0;
        Cursor dataCV = database.getData("SELECT Id FROM category where Type='"+type+"'");
        try{
            while (dataCV.moveToNext()) {
                id = dataCV.getInt(0);
            }
        }catch (SQLException e){
        }finally {
            database.close();
            dataCV.close();
        }

        return id;
    }



}
