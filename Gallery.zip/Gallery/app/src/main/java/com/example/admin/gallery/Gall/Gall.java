package com.example.admin.gallery.Gall;

public class Gall {
    private long id;
    private String ten;
    private String mota;
    private byte[] hinh;
    private String state;

    public Gall(long id, String ten, String mota, byte[] hinh,String state) {
        this.id = id;
        this.ten = ten;
        this.mota = mota;
        this.hinh = hinh;
        this.state = state;
    }

    public Gall() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getMota() {
        return mota;
    }

    public void setMota(String mota) {
        this.mota = mota;
    }

    public byte[] getHinh() {
        return hinh;
    }

    public void setHinh(byte[] hinh) {
        this.hinh = hinh;
    }

    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
}
