package com.example.admin.gallery.Gall;

public class GallCategory  {

    private Category idCategory;
    private Gall idGall;

    public GallCategory() {
    }

    public GallCategory(Category idCategory, Gall idGall) {
        this.idCategory = idCategory;
        this.idGall = idGall;
    }

    public Category getIdCategory() {
        return idCategory;
    }

    public void setIdCategory(Category idCategory) {
        this.idCategory = idCategory;
    }

    public Gall getIdGall() {
        return idGall;
    }

    public void setIdGall(Gall idGall) {
        this.idGall = idGall;
    }
}
