package com.example.admin.gallery.Gall;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;

import com.example.admin.gallery.database.Database;

import java.util.ArrayList;
import java.util.List;

public class GallCatDao {
    GallDao gd ;
    private Database database;
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "gallery.db";
    private static final String TABLE_CAT= "category_gall";
    private static final String COLUMN_idCategory = "idCategory";
    private static final String COLUMN_idGall = "idGall";

    private String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_CAT + "("
            + COLUMN_idCategory + " INTEGER," + COLUMN_idGall + " INTEGER,PRIMARY KEY (idCategory, idGall))";

    private String DROP_TABLE = "DROP TABLE IF EXISTS " + TABLE_CAT;

    public GallCatDao(Context context) {
        database = new Database(context, DATABASE_NAME, null, DATABASE_VERSION);
        database.queryData(CREATE_TABLE);
        gd = new GallDao(context);
    }

    public void addGallCatDao(GallCategory ct) {
        String sql = "INSERT INTO category_gall(idCategory,idGall) VALUES('"+ct.getIdCategory().getId()+"','"+gd.getSize()+"')";
        try{
            database.queryData(sql);
        }catch (SQLException e){

        }finally {
            database.close();
        }

    }

    public List<Gall> getGallByNameCategory(String nameCategory) {
        List<Gall> gallList = new ArrayList<Gall>();
        Cursor dataCV = database.getData("SELECT gl.id,gl.Ten,gl.MoTa,gl.HinhAnh FROM gall as gl, category as ct, category_gall as cg " +
                " where state ='1' and gl.id=cg.idGall and ct.id = cg.idCategory and ct.Type ='"+nameCategory+"'");
        Gall gall = null;
        try{
            while (dataCV.moveToNext()) {
                long id = dataCV.getLong(0);
                String Ten = dataCV.getString(1);
                String MoTa = dataCV.getString(2);
                byte[] HinhAnh = dataCV.getBlob(3);
                gall = new Gall(id, Ten, MoTa, HinhAnh,"1");
                gallList.add(gall);
            }
        }catch (SQLException e){

        }finally {
            database.close();
            dataCV.close();
        }

        return gallList;
    }

    public long getSizeGallCategory(String nameCategory) {
        Cursor dataCV = database.getData("SELECT count(*) FROM gall as gl, category as ct, category_gall as cg " +
                " where state ='1' and gl.id=cg.idGall and ct.id = cg.idCategory and ct.Type ='"+nameCategory+"'");
        long id =0;
        try{
            while (dataCV.moveToNext()) {
                id = dataCV.getInt(0);

            }
        }catch (SQLException e){

        }finally {
            database.close();
            dataCV.close();
        }

        return id;
    }

}
