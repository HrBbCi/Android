package com.example.admin.gallery.Gall;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import com.example.admin.gallery.database.Database;

import java.util.ArrayList;
import java.util.List;

public class GallDao {
    private Database database;
    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "gallery.db";

    private static final String TABLE_GAL = "gall";

    private static final String COLUMN_ID = "Id";
    private static final String COLUMN_NAME = "Ten";
    private static final String COLUMN_MOTA = "MoTa";
    private static final String COLUMN_HINHANH = "HinhAnh";
    private static final String COLUMN_STATE = "State";

    private String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_GAL + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_NAME + " VARCHAR(150),"
            + COLUMN_MOTA + " VARCHAR(150)," + COLUMN_HINHANH + " BLOB," + COLUMN_STATE + " VARCHAR(150))";

    public GallDao(Context context) {
        database = new Database(context, DATABASE_NAME, null, 1);
        database.queryData(CREATE_TABLE);
    }

    public void addGall(Gall gl) {
        try {
            SQLiteDatabase database1 = database.getWritableDatabase();
            String sql = "INSERT INTO gall(Ten,MoTa,HinhAnh,State) VALUES(?,?,?,?)";
            SQLiteStatement statement = database1.compileStatement(sql);
            statement.clearBindings();
            statement.bindString(1, gl.getTen());
            statement.bindString(2, gl.getMota());
            statement.bindBlob(3, gl.getHinh());
            statement.bindString(4, "1");
            statement.executeInsert();
        } catch (SQLException e) {
        } finally {
            database.close();
        }

    }

    public List<Gall> getAllGall() {
        List<Gall> gallList = new ArrayList<Gall>();
        Cursor dataCV = database.getData("SELECT * FROM gall where state ='1'");
        Gall gall = null;
        try {
            while (dataCV.moveToNext()) {
                long id = dataCV.getInt(0);
                String Ten = dataCV.getString(1);
                String MoTa = dataCV.getString(2);
                byte[] HinhAnh = dataCV.getBlob(3);
                gall = new Gall(id, Ten, MoTa, HinhAnh, "1");
                gallList.add(gall);
            }
        } catch (SQLException e) {

        } finally {
            database.close();
            dataCV.close();
        }
        return gallList;
    }

    public long getSize() {
        Cursor dataCV = database.getData("SELECT count(*) FROM gall");
        long id = 0;
        try {
            while (dataCV.moveToNext()) {
                id = dataCV.getInt(0);

            }
        } catch (SQLException e) {
        } finally {
            database.close();
            dataCV.close();
        }

        return id;
    }

    public boolean updateGal(Gall s) {
        try {
            SQLiteDatabase database1 = database.getWritableDatabase();
            String sql = "UPDATE gall SET TEN =?, MoTa=?,HinhAnh=? WHERE Id =?";
            SQLiteStatement statement = database1.compileStatement(sql);
            statement.clearBindings();
            statement.bindString(1, s.getTen());
            statement.bindString(2, s.getMota());
            statement.bindBlob(3, s.getHinh());
            statement.bindLong(4, s.getId());
            statement.executeInsert();
            return true;
        } catch (SQLException e) {
        } finally {
            database.close();
        }
        return false;
    }

    public void deleteGall(long id) {
        String sql = "UPDATE gall SET state ='0'"
                + " WHERE Id ='" + id + "'";
        database.queryData(sql);
    }

}
