package com.example.admin.gallery.Gall;

public class Category  {

    private long id;
    private String type;
    private byte[] hinh;
    public Category() {
    }

    public Category(long id, String type, byte[] hinh) {
        this.id = id;
        this.type = type;
        this.hinh = hinh;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public byte[] getHinh() {
        return hinh;
    }

    public void setHinh(byte[] hinh) {
        this.hinh = hinh;
    }
}
