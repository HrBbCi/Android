package com.example.admin.gallery.Gall;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.admin.gallery.R;
import com.example.admin.gallery.gallery.DetailActivity;

import java.util.ArrayList;
import java.util.List;

public class CategoryAdapter extends BaseAdapter {
    private Context context;
    private int layout;
    private List<Category> listDV;

    public CategoryAdapter(Context context, int layout, List<Category> listDV) {
        this.context = context;
        this.layout = layout;
        this.listDV = listDV;
    }

    @Override
    public int getCount() {
        return listDV.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    private class ViewHoler{
        ImageView imgHinh;
        TextView tvType;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHoler holer ;
        if(convertView == null){
            holer = new ViewHoler();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(layout,null);
            holer.tvType = (TextView) convertView.findViewById(R.id.tvType);
            holer.imgHinh =(ImageView) convertView.findViewById(R.id.ivHinhCate);

            convertView.setTag(holer);
        }else{
            holer = (ViewHoler) convertView.getTag();
        }
        final Category ct = listDV.get(position);
        holer.tvType.setText(ct.getType());

        byte[] hinhAnh = ct.getHinh();
        Bitmap bitmap = BitmapFactory.decodeByteArray(
                hinhAnh,0,hinhAnh.length
        );
        holer.imgHinh.setImageBitmap(bitmap);
        holer.imgHinh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GallCatDao gcd = new GallCatDao(context);
                List<Gall> list = new ArrayList<>();
                list = gcd.getGallByNameCategory(ct.getType().toString());
                Intent intent = new Intent(context,DetailActivity.class);
                intent.putExtra("idGal", ct.getId());
                intent.putExtra("type", ct.getType().toString());
                Log.d("TYPE",ct.getType().toString());
                context.startActivity(intent);
            }
        });
        return convertView;
    }

}
