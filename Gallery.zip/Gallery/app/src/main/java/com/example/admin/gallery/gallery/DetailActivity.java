package com.example.admin.gallery.gallery;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.admin.gallery.Gall.Category;
import com.example.admin.gallery.Gall.CategoryDao;
import com.example.admin.gallery.Gall.DetailAdapter;
import com.example.admin.gallery.Gall.Gall;
import com.example.admin.gallery.Gall.GallCatDao;
import com.example.admin.gallery.Gall.GallCategory;
import com.example.admin.gallery.Gall.GallDao;
import com.example.admin.gallery.R;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;

public class DetailActivity extends AppCompatActivity {

    GridView gv;
    GallDao gd;
    GallCatDao gcd;
    DetailAdapter detailAdapter;
    Intent intent;
    final int REQUEST_CODE_CAMERA = 123;
    final int REQUEST_CODE_FOLDER = 456;
    ImageView imgHinh;
    ImageButton ibCam, ibFolder;
    CategoryDao cd;
    GridView gvCategory;
    ListView listView;
    ArrayList<Gall> list;
    ArrayList<Gall> arrlistView;
    int idGal;
    String type;
    boolean change = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        initViews();
        initObj();


        intent = getIntent();
        gd = new GallDao(DetailActivity.this);
        cd = new CategoryDao(DetailActivity.this);
        gcd = new GallCatDao(DetailActivity.this);

        Intent i = getIntent();
        idGal = i.getIntExtra("idGal", 1);
        type = i.getStringExtra("type");

        detailAdapter = new DetailAdapter(this, R.layout.item_detail, list);
        getDataFromSQLite();
        gv.setAdapter(detailAdapter);
    }

    private void initViews() {
        gv = (GridView)findViewById(R.id.gvDetail);
        listView =(ListView) findViewById(R.id.listView);
    }

    private void initObj() {
        list = new ArrayList<>();
        arrlistView = new ArrayList<>();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.add_s, menu);
        MenuItem menuCollection = menu.findItem(R.id.menuCollection);
        if (change) {
            menuCollection.setTitle("ListView");
        } else {
            menuCollection.setTitle("GridView");
        }

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menuAdd:
                dialogThem();
                break;
            case R.id.menuCollection:
                if (change) {
                    change = false;
                    listView.setVisibility(View.VISIBLE);
                    gv.setVisibility(View.INVISIBLE);

                } else {
                    change = true;
                    listView.setVisibility(View.INVISIBLE);
                    gv.setVisibility(View.VISIBLE);
                }
                if(change){
                    //GridView
//                    list = (ArrayList<Gall>) gcd.getGallByNameCategory(type);
                    detailAdapter = new DetailAdapter(this, R.layout.item_detail, list);
                    getDataFromSQLite();
                    gv.setAdapter(detailAdapter);
                }else{
                    //ListView
//                    arrlistView = (ArrayList<Gall>) gcd.getGallByNameCategory(type);
                    detailAdapter = new DetailAdapter(this, R.layout.item_detail, list);
                    getDataFromSQLite();
                    listView.setAdapter(detailAdapter);
                }

                break;
                default:break;
        }

        return super.onOptionsItemSelected(item);
    }

    public void dialogThem() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_addgall);

        final EditText etName = (EditText)dialog.findViewById(R.id.etName);
        final EditText etMoTa =(EditText) dialog.findViewById(R.id.etMoTa);
        imgHinh =(ImageView) dialog.findViewById(R.id.imgHinh);
        ibCam =(ImageButton) dialog.findViewById(R.id.ibCam);
        ibFolder =(ImageButton) dialog.findViewById(R.id.ibFolder);
        Button btnAddImage =(Button) dialog.findViewById(R.id.btnAddImage);
        Button btnHuy =(Button) dialog.findViewById(R.id.btnHuy);

        btnAddImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString();
                String des = etMoTa.getText().toString();
                if (name == null || imgHinh == null) {
                    Toast.makeText(DetailActivity.this, "name not null", Toast.LENGTH_SHORT).show();
                } else {
                    Category ct = new Category();
                    GallCategory gc = new GallCategory();
                    Gall gl = new Gall();

                    byte[] hinhAnh = getByte(imgHinh);
                    gl.setId(idGal);
                    gl.setTen(name);
                    gl.setMota(des);
                    gl.setHinh(hinhAnh);

                    gd.addGall(gl);

                    long idCat = cd.findIDByType(type);
                    ct.setId(idCat);
                    ct.setType(type);

                    gc.setIdCategory(ct);
                    gc.setIdGall(gl);

                    gcd.addGallCatDao(gc);
                    Toast.makeText(DetailActivity.this, "Da them", Toast.LENGTH_SHORT).show();
                    getDataFromSQLite();
                    dialog.dismiss();
                }
            }
        });
        btnHuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        Camp(ibCam,ibFolder);
        dialog.show();
    }

    public void dialogSua(final Gall cv){
        final Dialog dialog = new Dialog(DetailActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_sua);
        final EditText etName = (EditText) dialog.findViewById(R.id.etName);
        final EditText etMoTa =  (EditText) dialog.findViewById(R.id.etMoTa);

        imgHinh = (ImageView) dialog.findViewById(R.id.imgHinh);
        ibCam = (ImageButton) dialog.findViewById(R.id.ibCam);
        ibFolder = (ImageButton) dialog.findViewById(R.id.ibFolder);

        Button btnEdit = (Button) dialog.findViewById(R.id.btnEdit);
        Button btnHuyEdit =(Button) dialog.findViewById(R.id.btnHuyEdit);
        Button btnXoa = (Button) dialog.findViewById(R.id.btnXoa);
        byte[] hinhAnh = cv.getHinh();
        imgHinh.setImageBitmap(bitMap(hinhAnh));

        etName.setText(cv.getTen());
        etMoTa.setText(cv.getMota());

        btnHuyEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cv.setId(cv.getId());
                cv.setTen(etName.getText().toString());
                cv.setMota(etMoTa.getText().toString());
                Bitmap bitmap = ((BitmapDrawable) imgHinh.getDrawable()).getBitmap();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] imageInByte = baos.toByteArray();
                cv.setHinh(imageInByte);
                boolean ff= gd.updateGal(cv);
                Toast.makeText(v.getContext(),"Update Success",Toast.LENGTH_SHORT).show();
                getDataFromSQLite();
                dialog.dismiss();
            }
        });
        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GallDao gd1 = new GallDao(DetailActivity.this);
                gd1.deleteGall(cv.getId());
                Toast.makeText(v.getContext(),"Delete Success",Toast.LENGTH_SHORT).show();
                getDataFromSQLite();
                dialog.dismiss();

            }
        });
        Camp(ibCam,ibFolder);
        dialog.show();
    }

    public void Camp(ImageButton ibCam, ImageButton ibFolder){
        ibCam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityCompat.requestPermissions(
                        DetailActivity.this,
                        new String[]{Manifest.permission.CAMERA},
                        REQUEST_CODE_CAMERA
                );


            }
        });

        ibFolder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, REQUEST_CODE_FOLDER);
            }
        });
    }
    private void getDataFromSQLite() {
        // AsyncTask is used that SQLite operation not blocks the UI Thread.
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                list.clear();
                list.addAll(gcd.getGallByNameCategory(type));
                arrlistView.clear();
                arrlistView.addAll(gcd.getGallByNameCategory(type));
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                detailAdapter.notifyDataSetChanged();
            }
        }.execute();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_CAMERA:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, REQUEST_CODE_CAMERA);
                } else {
                    Toast.makeText(this, "Ko dc phep", Toast.LENGTH_SHORT).show();
                }
                break;
            case REQUEST_CODE_FOLDER:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Intent intent = new Intent(Intent.ACTION_PICK);
                    intent.setType("image/*");
                    startActivityForResult(intent, REQUEST_CODE_CAMERA);
                } else {
                    Toast.makeText(this, "Ko dc phep", Toast.LENGTH_SHORT).show();
                }
                break;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == REQUEST_CODE_CAMERA && resultCode == RESULT_OK && data != null) {
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            imgHinh.setImageBitmap(bitmap);
        }
        if (requestCode == REQUEST_CODE_FOLDER && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                imgHinh.setImageBitmap(bitmap);

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    public byte[] getByte(ImageView imgHinh){
        BitmapDrawable bitmapDrawable = (BitmapDrawable) imgHinh.getDrawable();
        //Cnvert hinh anh qua  bitmap
        Bitmap bitmap = bitmapDrawable.getBitmap();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 50, baos);

        byte[] hinhAnh = baos.toByteArray();
        return hinhAnh;
    }

    public Bitmap bitMap(byte[] hinhAnh){
        ByteArrayInputStream imageStream = new ByteArrayInputStream(hinhAnh);
        Bitmap theImage = BitmapFactory.decodeStream(imageStream);
        return theImage;
    }

}
