package com.example.admin.gallery.gallery;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Gallery;
import android.widget.ImageView;

import com.example.admin.gallery.Gall.GalleryImageAdapter;
import com.example.admin.gallery.R;

public class GalleryTActivity extends AppCompatActivity {

    Gallery gl;
    Button btnBack;
    GalleryImageAdapter galleryImageAdapter;
    ImageView imgv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery_t);
        btnBack = (Button) findViewById(R.id.btnBack);
        imgv = (ImageView) findViewById(R.id.imgv);
        gl = (Gallery) findViewById(R.id.glr);

        gl.setSpacing(1);
        galleryImageAdapter = new GalleryImageAdapter(GalleryTActivity.this);
        gl.setAdapter(galleryImageAdapter);
        gl.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                imgv.setImageResource(galleryImageAdapter.arr[position]);
            }
        });
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(GalleryTActivity.this, CategoryActivity.class));
            }
        });
    }




}
